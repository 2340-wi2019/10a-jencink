<?php

	/*
		Plugin Name: 2340 Sample Plugin
		Plugin URL: https://faculty.mccneb.edu/grosas/
		Description: A sample plugin for INFO 2340.
		Version: 1.0
		Author Guillermo J. Rosas
		Author URI: https://faculty.mccneb.edu/grosas/
		License: GPL
	*/

	add_shortcode("wittyquote", "get_quote");

	function get_quote($atts) {
		$quotes = array (
			"We've arranged a civilzation in which most crucial elements profoundly depend on science and technology. - Carl Sagan",
			"Any sufficiently advanced technology is indistinguishable from magic. - Arthur C. Clarke",
			"Better than a thousand hollow words, is one word that brings peace. - Buddha",
			"Why need I volumes, if one word suffice? - Ralph Waldo Emerson",
			"It's always too early to quit. - Norman Vincent Peale"
		);

		return $quotes[array_rand($quotes)];
	}